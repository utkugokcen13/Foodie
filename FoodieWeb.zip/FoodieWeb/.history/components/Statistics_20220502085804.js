import React from 'react';
import Header from "../components/Header";
import Footer from "../components/Footer";
import SideMenu from "../components/SideMenu";
import PageContext from "../components/PageContext";

const active = {Statistics: "active"};
class Statistics extends React.Component {
    componentDidMount() {

    }
    constructor(props)
    {
        super(props);
    }
    render(props) {
        return (
            <div>
                <Header/>
                <SideMenu statistics="active"/>
                <PageContext>
                Statistics
                </PageContext>
                <Footer/>
            </div>);
    }
}


export default Statistics;
