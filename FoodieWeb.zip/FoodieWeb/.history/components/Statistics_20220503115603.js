import React from 'react';
import Header from "./Header";
import Footer from "./Footer";
import SideMenu from "./SideMenu";
import PageContext from "./PageContext";

const active = {Statistics: "active"};
class Statistics extends React.Component {
    componentDidMount() {

    }
    constructor(props)
    {
        super(props);
    }
    render(props) {
        return (
            <div>
                <Header/>
                <SideMenu statistics="active"/>
                <PageContext>
                Statistics
                </PageContext>
                <Footer/>
            </div>);
    }
}


export default Statistics;
