import React from 'react';
import Header from "./Header";
import Footer from "./Footer";
import SideMenu from "./SideMenu";
import PageContext from "./PageContext";

const active = {Payment: "active"};
class Payment extends React.Component {
    componentDidMount() {

    }
    constructor(props)
    {
        super(props);
    }
    render(props) {
        return (
            <div>
                <Header/>
                <SideMenu payment="active"/>
                <PageContext>
                Payment
                </PageContext>
                <Footer/>
            </div>);
    }
}


export default Payment;
