import React from 'react';
import { useRouter } from 'next/router'
import Header from '.Header'
import SideMenu from './SideMenu'
const Business = () => {
    const router = useRouter()
    return (
        <div>
        <Header/>
        <SideMenu payment="active"/>
      </div>
    )
  }
  
  export default Business
