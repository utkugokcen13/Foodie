import React from 'react';
import { useRouter } from 'next/router'
import Header from '../components/Header'
import SideMenu from '../components/SideMenu'
const Business = () => {
    const router = useRouter()
    return (
        <div>
        <Header/>
        <SideMenu payment="active"/>
      </div>
    )
  }
  
  export default Business
