import React from 'react';
import Header from "../components/Header";
import Footer from "../components/Footer";
import SideMenu from "../components/SideMenu";
import PageContext from "../components/PageContext";

const active = {Payment: "active"};
class Payment extends React.Component {
    componentDidMount() {

    }
    constructor(props)
    {
        super(props);
    }
    render(props) {
        return (
            <div>
                <Header/>
                <SideMenu payment="active"/>
                <PageContext>
                Payment
                </PageContext>
                <Footer/>
            </div>);
    }
}


export default Payment;
