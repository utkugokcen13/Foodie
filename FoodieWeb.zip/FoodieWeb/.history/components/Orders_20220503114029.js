import React from 'react';
import Header from "../components/Header";
import Footer from "../components/Footer";
import SideMenu from "../components/SideMenu";
import PageContext from "../components/PageContext";
import CustomTable from "../components/CustomTable";

class Order extends React.Component {

    componentDidMount(props) {

        this.getTotalRow();
    }
    constructor(props)
    {
        
        super(props);
        this.state = {
            pageCount:0,
            totalRow:0,
            startRow:0,
            endRow:0,
            content:[],
            title:["Name","Order","Total Amount","Order Date","Payment Method",""],
            statePast:{
                pageCount:0,
            totalRow:0,
            startRow:0,
            endRow:0,
            content:[],
            title:["Order Number","Customer","Total Amount","Order Date","Payment Method","Status"],
            },
            stateActive:{
                pageCount:0,
            totalRow:0,
            startRow:0,
            endRow:0,
            content:[],
            title:["Order Number","Customer","Total Amount","Order Date","Payment Method","Status"],
            }
        };
        
    }
    getTotalRow = ()=>{
        
        let totalRow = [{"name":"John Doe","order":"Soup","total":"29.99 TL","date":"06.01.2022 14.29","method":"Online"},
        {"name":"Dummy Name","order":"Salad","total":"129.99 TL","date":"06.01.2022 14.32","method":"Online"},
        {"name":"John Doe9","order":"Soup","total":"29.99 TL","date":"06.01.2022 14.29","method":"Online"},
        {"name":"John Doqe","order":"So2up","total":"29.929 TL","date":"06.02.2022 14.29","method":"Onlin2e"}];
        
        let content = totalRow.map((item) =>
        (<tr key = {item.id}>
                                    <td>{item.name}</td>
                                    <td>{item.order}</td>
                                    <td>{item.total}</td>
                                    <td>{item.date}</td>
                                    <td>{item.method}</td>
                                    <td>
                                        <button style={button} type="button"  className="btn btn-block btn-outline-success">Accept</button>
                                        <button style={button} type="button" className="btn btn-block btn-outline-danger"data-target="#modal-default">Reject</button>
                                    </td>
                                </tr>))
        this.setState({content:content});
    }

    getTotalRowActive = ()=>{
    }
    getTotalRowPast = ()=>{
    }
    render(props) {
        return (
            <div>
                <Header/>
                <SideMenu orders="active"/>
                <PageContext>
                <div className="card">
                        <div className="card-header">
                            <h3 className="card-title">Order Requests</h3>
                        </div>
                        <div className="card-body">
                            <CustomTable state={this.state} getTotalRow={this.getTotalRow} ></CustomTable>
                        </div>
                      
                    </div>
                    <div className="card">
                        <div className="card-header">
                            <h3 className="card-title">Active Orders (1)</h3>
                        </div>
                        <div className="card-body">
                            <CustomTable state={this.state.stateActive} getTotalRow={this.getTotalRowActive} ></CustomTable>
                        </div>
                      
                    </div>
                    <div className="card">
                        <div className="card-header">
                            <h3 className="card-title">Past Orders (2)</h3>
                        </div>
                        <div className="card-body">
                            <CustomTable state={this.state.statePast} getTotalRow={this.getTotalRowPast} ></CustomTable>
                        </div>
                      
                    </div>
                </PageContext>
                <Footer/>
            </div>);
    }
}

const button = {
    marginTop: "0px",
    marginLeft: "10px",
    float: "left",
    width: "100px"
};
export default Order;
