import React from 'react';
import Link from 'next/link'
class SideMenu extends React.Component {
    
    render(props) {
        return (
            <aside className="main-sidebar sidebar-dark-primary elevation-4">
                <Link href="Business/" className="brand-link">
                    <a><span className="brand-text font-weight-light">Foodie</span></a>
                </Link>

                <div className="sidebar">
                   

                    <nav className="mt-2">
                        <ul className="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                            data-accordion="false">
                            <li className="nav-item">
                                <Link href="/" className={this.props.home + " nav-link "+this.showHome}>
                                <a><i className="nav-icon fas fa-home"/>
                                    <p>
                                        Main Page
                                    </p></a>
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link href="Business/Orders"  className={this.props.orders + " nav-link "+this.showorders}>
                                    <a><i className="nav-icon fas  fa-book"/>
                                    <p>
                                       Orders
                                    </p>
                                </a>
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link href="Business/Menu"  className={this.props.menu + " nav-link "+this.showmenu}>
                                    <a><i className="nav-icon fas  fa-book"/>
                                    <p>
                                       Menu
                                    </p></a>
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link href="Business/Payment"  className={this.props.payment + " nav-link "+this.showpayment}>
                                    <a><i className="nav-icon fas  fa-book"/>
                                    <p>
                                        Payment Methods
                                    </p></a>
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link href="Business/Working"  className={this.props.working + " nav-link "+this.showworking}>
                                    <a><i className="nav-icon fas  fa-book"/>
                                    <p>
                                        Working Hours
                                    </p></a>
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link href="Business/Statistics"  className={this.props.statistics + " nav-link "+this.showstatistics}>
                                    <a><i className="nav-icon fas  fa-book"/>
                                    <p>
                                        Statistics
                                    </p></a>
                                </Link>
                            </li>
                        </ul>
                    </nav>
                </div>
            </aside>
        );
    }
}

export default SideMenu;
