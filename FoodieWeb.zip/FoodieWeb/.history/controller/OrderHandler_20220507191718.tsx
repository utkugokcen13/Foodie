import { useAuth } from './AuthContext'
import { getDatabase, ref, get, onValue, child,onChildAdded, onChildRemoved } from "firebase/database";
import { useEffect } from 'react'
let  totalRow: Object[] 
let  totalRowActive: Object[]
let  totalRowPast: Object[]
const OrderHandler = () => {
    const {user} = useAuth()   
    const db = getDatabase()
    const theRef = ref(db, 'Users/' + user.uid + '/businessName');
    onChildAdded(theRef, (data) => {
        alert("eklendi")
    });
    onChildRemoved(theRef, (data) => {
        alert("kaldirdildi")
      });
    let businessName: String
    get(child(ref(getDatabase()), 'Users/' + user.uid + '/businessName' )).then((snapshot) => {
        if (snapshot.exists()) {
            businessName = snapshot.val()
            
        }
    })
    useEffect(() =>{
            totalRow = []
            const dbRef = ref(getDatabase(), 'Business/' + businessName + '/Orders/requested_orders');
            onValue(dbRef, (snapshot) => {
                snapshot.forEach((childSnapshot) => {
                let deneme: any = {}
                childSnapshot.forEach((childSnapshot2) =>{
                    const childKey = childSnapshot2.key;
                    const childData = childSnapshot2.val();
                    deneme[String(childKey)] = childData
                })
                totalRow.push(deneme)
                });
            },{
                onlyOnce: false
            });
            console.log(totalRow)
    }, [totalRow])
    useEffect(() =>{
            totalRowActive = []
            const dbRef = ref(getDatabase(), 'Business/' + businessName + '/Orders/active_orders');
            onValue(dbRef, (snapshot) => {
                snapshot.forEach((childSnapshot) => {
                let deneme: any = {}
                childSnapshot.forEach((childSnapshot2) =>{
                    const childKey = childSnapshot2.key;
                    const childData = childSnapshot2.val();
                    deneme[String(childKey)] = childData
                })
                totalRowActive.push(deneme)
                });
            },{
                onlyOnce: false
            });
        
    }, [totalRowActive])
    useEffect(() =>{
            totalRowPast = []
            const dbRef = ref(getDatabase(), 'Business/' + businessName + '/Orders/past_orders');
            onValue(dbRef, (snapshot) => {
                snapshot.forEach((childSnapshot) => {
                let deneme: any = {}
                childSnapshot.forEach((childSnapshot2) =>{
                    const childKey = childSnapshot2.key;
                    const childData = childSnapshot2.val();
                    deneme[String(childKey)] = childData
                })
                totalRowPast.push(deneme)
                });
            },{
                onlyOnce: false
            });
        
    }, [totalRowPast])

}
export {totalRow, totalRowActive, totalRowPast}
export default OrderHandler

