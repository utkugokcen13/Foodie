import { useAuth } from './AuthContext'
import { getDatabase, ref, get, onValue, child } from "firebase/database";
const OrderHandler2 = () => {
    const { user } = useAuth()



}

export OrderHandler2