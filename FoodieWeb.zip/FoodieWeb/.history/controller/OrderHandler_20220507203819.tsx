import { useAuth } from './AuthContext'
import { getDatabase, ref, get, onValue, child,onChildAdded, onChildRemoved } from "firebase/database";
import { useEffect, useState } from 'react'
let  totalRow: Object[] 
let  totalRowActive: Object[]
let  totalRowPast: Object[]
const OrderHandler = () => {
    const {user} = useAuth()   
    let  initialState: Object[] = []
    const [requested, setRequested] = useState(initialState)
    const [active, setActive] = useState(initialState)
    const [past, setPast] = useState(initialState)
    useEffect(() =>{
        get(child(ref(getDatabase()), 'Users/' + user.uid + '/businessName' )).then((snapshot) => {
            if (snapshot.exists()) {
                const businessName = snapshot.val()
                
            let temp: Object[] = []
            const dbRef = ref(getDatabase(), 'Business/' + businessName + '/Orders/requested_orders');
            onValue(dbRef, (snapshot) => {
                snapshot.forEach((childSnapshot) => {
                let deneme: Object = {}
                childSnapshot.forEach((childSnapshot2) =>{
                    const childKey = childSnapshot2.key;
                    const childData = childSnapshot2.val();
                    deneme[String(childKey)] = childData
                })
                temp.push(deneme)
                });
            },{
                onlyOnce: false
            });
            setRequested(temp)
            totalRow = requested
    }})
        
    }, [totalRow])
    useEffect(() =>{
        get(child(ref(getDatabase()), 'Users/' + user.uid + '/businessName' )).then((snapshot) => {
            if (snapshot.exists()) {
                const businessName = snapshot.val()
                    
            let temp: Object[] = []
            const dbRef = ref(getDatabase(), 'Business/' + businessName + '/Orders/active_orders');
            onValue(dbRef, (snapshot) => {
                snapshot.forEach((childSnapshot) => {
                let deneme: Object = {}
                childSnapshot.forEach((childSnapshot2) =>{
                    const childKey = childSnapshot2.key;
                    const childData = childSnapshot2.val();
                    deneme[String(childKey)] = childData
                })
                temp.push(deneme)
                });
            },{
                onlyOnce: false
            });
            setActive(temp)
            totalRowActive = active
    }})
        
    }, [totalRowActive])
    useEffect(() =>{
        get(child(ref(getDatabase()), 'Users/' + user.uid + '/businessName' )).then((snapshot) => {
            if (snapshot.exists()) {
                const businessName = snapshot.val()
            
            let temp: Object[] = []
            const dbRef = ref(getDatabase(), 'Business/' + businessName + '/Orders/past_orders');
            onValue(dbRef, (snapshot) => {
                snapshot.forEach((childSnapshot) => {
                let deneme: Object = {}
                childSnapshot.forEach((childSnapshot2) =>{
                    const childKey = childSnapshot2.key;
                    const childData = childSnapshot2.val();
                    deneme[String(childKey)] = childData
                })
                temp.push(deneme)
                });
            },{
                onlyOnce: false
            });
            setPast(temp)
            totalRowPast = past
    }})
        
    }, [totalRowPast])
}
export {totalRow, totalRowActive, totalRowPast}
export default OrderHandler

/* 
const theRef = ref(db, 'Users/' + user.uid + '/businessName');
    onChildAdded(theRef, (data) => {
        alert("eklendi")
    });
    onChildRemoved(theRef, (data) => {
        alert("kaldirdildi")
      });

*/