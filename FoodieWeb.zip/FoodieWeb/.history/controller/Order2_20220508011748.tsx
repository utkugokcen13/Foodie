import { useAuth } from './AuthContext'
import { getDatabase, ref, get, onValue, child } from "firebase/database";
export const OrderHandler2 = () => {
    const { user } = useAuth()



}
