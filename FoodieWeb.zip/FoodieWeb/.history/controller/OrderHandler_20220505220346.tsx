import { useAuth } from './AuthContext'
import { useRouter } from 'next/router'
import { getDatabase, ref, get, onValue, child } from "firebase/database";
import React, { useState } from 'react'

const OrderHandler = () => {
    let  totalRow: Object[] = [] 
    const {user} = useAuth()   
    const [state, setState] = useState(0)
    get(child(ref(getDatabase()), 'Users/' + user.uid + '/businessName' )).then((snapshot) => {
        if (snapshot.exists()) {
             let businessName = snapshot.val()
            console.log(businessName)
             const dbRef = ref(getDatabase(), 'Business/' + businessName + '/Orders/requested_orders');

             onValue(dbRef, (snapshot) => {
               snapshot.forEach((childSnapshot) => {
                 const childKey = childSnapshot.key;
                 const childData = childSnapshot.val();
                 let deneme: any = {}
                 deneme.name = "memerw"
                 deneme.order = "memer"
                 deneme.total = "memer"
                 deneme.date = "memer"
                 deneme.method = "memer"
                 totalRow.push(deneme)
               });
             }, {
               onlyOnce: true
             });
        }
    })
    return <>{totalRow}</>
}
export default OrderHandler
