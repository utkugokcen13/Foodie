import { useAuth } from './AuthContext'
import { useRouter } from 'next/router'
import { getDatabase, ref, get, onValue, child } from "firebase/database";
import React, { useEffect } from 'react'

let  totalRow: Object[] = [] 
const OrderHandler = () => {
    const {user} = useAuth()   
    useEffect(() =>{
        get(child(ref(getDatabase()), 'Users/' + user.uid + '/businessName' )).then((snapshot) => {
            if (snapshot.exists()) {
                let businessName = snapshot.val()
                totalRow = []
                const dbRef = ref(getDatabase(), 'Business/' + businessName + '/Orders/requested_orders');
                onValue(dbRef, (snapshot) => {
                    let deneme: any = {}
                    snapshot.forEach((childSnapshot) => {
                    childSnapshot.forEach((childSnapshot2) =>{
                        const childKey = childSnapshot2.key;
                        const childData = childSnapshot2.val();
                        deneme[String(childKey)] = childData
                        
                    }
                    )
                    totalRow.push(deneme)
                    });
                }, {
                   onlyOnce: true
                });
                
            }
        })
    }, [totalRow])
}
export {totalRow}
export default OrderHandler
