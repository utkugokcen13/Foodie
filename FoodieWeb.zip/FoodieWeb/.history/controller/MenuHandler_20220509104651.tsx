import { useAuth } from './AuthContext'
import { getDatabase, get, onValue, child, ref, remove, set } from "firebase/database";
import { getStorage, ref as ref2, uploadBytes } from "firebase/storage"; 
let  MenuTotal: Object[]
let accepted = false
const MenuHandler = () => {
    const {user} = useAuth()    
    let loading = false
    const storage = getStorage();
    const getList = (dbRef: any)=>{
        const temp: Object[] = []
        onValue(dbRef, (snapshot) => {
            snapshot.forEach((childSnapshot) => {
            let deneme: Object = {}
            deneme["mealID"] = childSnapshot.key
            childSnapshot.forEach((childSnapshot2) =>{
                const childKey = childSnapshot2.key;
                const childData = childSnapshot2.val();
                deneme[String(childKey)] = childData
            })
            temp.push(deneme)
            });
        },{
            onlyOnce: true
        });
        return temp
    }
    if(accepted){
        loading = true
        if((typeof MenuTotal !== 'undefined')){
            get(child(ref(getDatabase()), 'Users/' + user.uid + '/businessName' )).then((snapshot) => {
                if (snapshot.exists()) {
                    const businessName = snapshot.val()
                    
                    remove(ref(getDatabase(), 'Business/' + businessName + '/Menu'))
                        
                    
                    for (let index = 0; index < MenuTotal.length; index++) {
                        console.log(MenuTotal.length)
                        set(ref(getDatabase(), 'Business/' + businessName + '/Menu/' + MenuTotal[index]["mealID"]), {
                            meal_description: MenuTotal[index]["meal_description"],
                            meal_price: MenuTotal[index]["meal_price"],
                            meal_discounted_price: MenuTotal[index]["meal_discounted_price"],
                            meal_name: MenuTotal[index]["meal_name"],
                        });
                    }
                }
            })
        }
        loading = false
        accepted = false
    }
    get(child(ref(getDatabase()), 'Users/' + user.uid + '/businessName' )).then((snapshot) => {
        if (snapshot.exists()&& !loading) {
            
            let businessName = snapshot.val()
            
            const dbRef = ref(getDatabase(), 'Business/' + businessName + '/Menu');
            MenuTotal = getList(dbRef)
        }
    })
}
export const removeMeal = (mealID: any) =>{
    console.log("removal")
    if(!(typeof MenuTotal === 'undefined')){
        accepted = true
        const index = (MenuTotal.findIndex(a => a["mealID"] === mealID))
        if(!(typeof index === 'undefined')){
            MenuTotal.splice(index, 1)
        }
    }
}
export const updateMeal = (mealID: any,content: any, title: any, payment1: any, payment2: any, imageURL: any) =>{
    console.log("update")
    accepted = true
    let deneme: Object = {}
    deneme["content"] = content,
    deneme["title"] = title,
    deneme["payment1"] = payment1,
    deneme["payment2"] = payment2,
    deneme["image"] = imageURL,
    deneme["mealID"] = mealID
    if(!(typeof MenuTotal === 'undefined')){
        const index = (MenuTotal.findIndex(a => a["mealID"] === mealID))
        if(!(typeof index === 'undefined')){
            console.log(deneme["content"])
            MenuTotal[index] = deneme
        }
    }
}
export const addMeal = (content: any, title: any, payment1: any, payment2: any, imageURL: any) =>{
    console.log("add")
    accepted = true
    let deneme: Object = {}
    deneme["content"] = content,
    deneme["title"] = title,
    deneme["payment1"] = payment1,
    deneme["payment2"] = payment2,
    deneme["image"] = imageURL
    deneme["mealID"] = "id" + Math.random().toString(16).slice(2)
    if(!(typeof MenuTotal === 'undefined')){
        MenuTotal.push(deneme)
    }else{
        MenuTotal = []
        MenuTotal.push(deneme)
    }
}
export {MenuTotal}
export default MenuHandler