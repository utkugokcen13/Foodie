import { useAuth } from './AuthContext'
import { useRouter } from 'next/router'
import { getDatabase, ref, get, onValue, child } from "firebase/database";
import React, { useState } from 'react'


let  totalRow: Object[] = [] 

const OrderHandler = () => {
    const {user} = useAuth()   

    get(child(ref(getDatabase()), 'Users/' + user.uid + '/businessName' )).then((snapshot) => {
        if (snapshot.exists()) {
             let businessName = snapshot.val()
            console.log(businessName)
             const dbRef = ref(getDatabase(), 'Business/' + businessName + '/Orders/requested_orders');

             onValue(dbRef, (snapshot) => {
               snapshot.forEach((childSnapshot) => {
                 const childKey = childSnapshot.key;
                 const childData = childSnapshot.val();
                 let deneme: any = {}
                 deneme.name = "meme"
                 deneme.order = "meme"
                 deneme.total = "meme"
                 deneme.date = "meme"
                 deneme.method = "meme"
                 totalRow.push(deneme)
               });
             }, {
               onlyOnce: false
             });
        }
    })

    
}
console.log(totalRow)
export {totalRow}
export default OrderHandler
