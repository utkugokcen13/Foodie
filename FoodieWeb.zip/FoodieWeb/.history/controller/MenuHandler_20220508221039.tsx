import { useAuth } from './AuthContext'
import { getDatabase, ref, get, onValue, child } from "firebase/database";
import React, { useState } from 'react'
let  MenuTotal: Object[]
const MenuHandler = () => {
    const {user} = useAuth()    

    const getList = (dbRef: any)=>{
        const temp: Object[] = []
        onValue(dbRef, (snapshot) => {
            snapshot.forEach((childSnapshot) => {
            let deneme: Object = {}
            deneme["mealID"] = childSnapshot.key
            childSnapshot.forEach((childSnapshot2) =>{
                const childKey = childSnapshot2.key;
                const childData = childSnapshot2.val();
                deneme[String(childKey)] = childData
            })
            temp.push(deneme)
            });
        },{
            onlyOnce: true
        });
        return temp
    }
    get(child(ref(getDatabase()), 'Users/' + user.uid + '/businessName' )).then((snapshot) => {
        if (snapshot.exists()) {
             let businessName = snapshot.val()
            console.log(businessName)
             const dbRef = ref(getDatabase(), 'Business/' + businessName + '/Orders/requested_orders');
             MenuTotal = getList(dbRef)
        }
    })
}
    
export {MenuTotal}
export default MenuHandler