import { useAuth } from './AuthContext'
import { useRouter } from 'next/router'
import { getDatabase, ref, get, onValue, child } from "firebase/database";
import React, { useState } from 'react'

let totalRow: Object[] = []

let businessName = ''
const OrderHandler = () => {
    const {user} = useAuth()    
    get(child(ref(getDatabase()), 'Users/' + user.uid + '/businessName' )).then((snapshot) => {
        if (snapshot.exists()) {
             businessName = snapshot.val()


            
        }
    })

    console.log(businessName)
    
    
}
export {totalRow}
export default OrderHandler
