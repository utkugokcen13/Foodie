import { useAuth } from './AuthContext'
import { useRouter } from 'next/router'

let totalRow = [{"name":"John Doe","order":"Soup","total":"29.99 TL","date":"06.01.2022 14.29","method":"Online"},
{"name":"Dummy Name","order":"Salad","total":"129.99 TL","date":"06.01.2022 14.32","method":"Onliner"}];


const OrderHandler = () => {
    const {user, login} = useAuth()    
    const router = useRouter()
    
    if(user){
        console.log(user.email)
    }else{
        console.log("nullo")
    }
    return <div></div>

    
}
export {totalRow}
export default OrderHandler
