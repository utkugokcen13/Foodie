import React, { useState } from 'react'
import { useRouter } from 'next/router'
import { useAuth } from '../context/AuthContext'

let totalRow = [{"name":"John Doe","order":"Soup","total":"29.99 TL","date":"06.01.2022 14.29","method":"Online"},
{"name":"Dummy Name","order":"Salad","total":"129.99 TL","date":"06.01.2022 14.32","method":"Onliner"}];


const OrderHandler = () => {
    const {user} = useAuth()    
    const router = useRouter()

    console.log(user.uid)
    
}
export {totalRow}
