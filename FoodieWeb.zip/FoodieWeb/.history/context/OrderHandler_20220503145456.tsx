import { useAuth } from './AuthContext'
import { useRouter } from 'next/router'

let totalRow = [{}];


const OrderHandler = () => {
    const {user, login} = useAuth()    
    const router = useRouter()
    
    
    
}
export {totalRow}
export default OrderHandler
