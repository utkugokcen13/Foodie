import { useRouter } from 'next/router'
import { useAuth } from '../context/AuthContext'


const OrderHandler = () => {
    const router = useRouter()
    const {user} = useAuth()


    return (
        
    )

}

export default OrderHandler