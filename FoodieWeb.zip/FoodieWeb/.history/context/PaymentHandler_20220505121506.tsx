import { useAuth } from './AuthContext'
import { useRouter } from 'next/router'
import { getDatabase, ref, get, onValue, child } from "firebase/database";
import React, { useState } from 'react'

const PaymentHandler = () => {
    const {user} = useAuth()    
    get(child(ref(getDatabase()), 'Users/' + user.uid + '/businessName' )).then((snapshot) => {
        if (snapshot.exists()) {
             let businessName = snapshot.val()
  
        }
    })
}
    

export default PaymentHandler