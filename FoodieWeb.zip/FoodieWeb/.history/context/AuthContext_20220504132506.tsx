import { createContext, useContext, useEffect, useState } from 'react'
import {
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
} from 'firebase/auth'
import { auth } from '../config/firebase'
import { getDatabase, ref, set } from "firebase/database";

const AuthContext = createContext<any>({})

export const useAuth = () => useContext(AuthContext)

export const AuthContextProvider = ({
  children,
}: {
  children: React.ReactNode
}) => {
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setUser({
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          businessName: ''
        })
      } else {
        setUser(null)
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])
  
  const signup = (email: string, password: string) => {
    return createUserWithEmailAndPassword(auth, email, password)
  }
  
  const login = (email: string, password: string) => {
    return signInWithEmailAndPassword(auth, email, password)
  }

  const logout = async () => {
    setUser(null)
    await signOut(auth)
  }
  const writeBusinessData = (businessName : string, businessType : string, latitude: number, longitude: number, avgRating: number) =>{
    return set(ref(getDatabase(), 'Business/' + businessName),{
      businessName: businessName,
      businessType: businessType,
      latitude: latitude,
      longitude: longitude,
      avgRating: avgRating
    })
  }
  const writeUserData = (businessName : string, uid: string) =>{
    return set(ref(getDatabase(), 'Users/' + uid),{
      businessName: businessName
    })
  }
  return (
    <AuthContext.Provider value={{ user, login, signup, logout, writeBusinessData,writeUserData }}>
      {loading ? null : children}
    </AuthContext.Provider>
  )
}