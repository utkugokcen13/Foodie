import { useRouter } from 'next/router'
import React, { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import Order from '../components/Orders'

const ListMaker = () =>{
    const annen = "anne nasilsin armut dalda asilsin"
}
asdasda

const OrderHandler = () => {
    const router = useRouter()
    const {user} = useAuth()


    return (
        <div>
            < Order/>
        </div>
    )

}

export default OrderHandler