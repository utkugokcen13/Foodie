import { useAuth } from './AuthContext'
import { useRouter } from 'next/router'
import { getDatabase, ref,onValue } from "firebase/database";
import React, { useState } from 'react'

let totalRow: Object[] = []


const OrderHandler = () => {
    const {user, login} = useAuth()    
    const router = useRouter()
    const db= getDatabase();
    
    const readVal = ref(db, 'Users/' + user.uid + '/businessName');
    onValue(readVal, (snapshot) => {
    const data = snapshot.val();
    console.log(data)
}
export {totalRow}
export default OrderHandler
