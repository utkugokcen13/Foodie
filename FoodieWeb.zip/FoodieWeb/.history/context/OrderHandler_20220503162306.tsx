import { useAuth } from './AuthContext'
import { useRouter } from 'next/router'
import { getDatabase, ref } from "firebase/database";
import React, { useState } from 'react'

let totalRow: Object[] = []


const OrderHandler = () => {
    const {user, login} = useAuth()    
    const router = useRouter()
    const db= getDatabase();
    
    user.b = 34;
    /*const theList = ref(db, 'Business' + user. + '/starCount');
    onValue(starCountRef, (snapshot) => {
    const data = snapshot.val();
    updateStarCount(postElement, data);*/
    
    
}
export {totalRow}
export default OrderHandler
